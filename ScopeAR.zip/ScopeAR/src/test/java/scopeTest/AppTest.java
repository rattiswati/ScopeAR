package scopeTest;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.Assert.assertTrue;

import java.util.Scanner;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;
import org.testng.Assert;
import org.testng.AssertJUnit;

public class AppTest 
{

	@Test(enabled = true, priority = 1)
	public void Test1XmasTree() {

		AssertJUnit.assertEquals(printChristmasTree(5), "Pattern printed successfully");

	}

	@Test(enabled = true, priority = 2)
	public void Test2XmasTree() {

		AssertJUnit.assertEquals(printChristmasTree(6), "Pattern printed successfully");
	}
	
	@Test(enabled = true, priority = 3)
	public void Test3XmasTree() {


		AssertJUnit.assertEquals(printChristmasTree(0), "Pattern not printed successfully");
		
	}

	@Test(enabled = true, priority = 4)
	public void Test4XmasTree() {

		AssertJUnit.assertEquals(printChristmasTree(-1), "Pattern not printed successfully");
	}
	
	@Test(enabled = true, priority = 5)
	public void Test1XPattern() {

		AssertJUnit.assertEquals(printXPattern(5), "Pattern printed successfully");
	}
	
	@Test(enabled = true, priority = 6)
	public void Test2XPattern() {

		AssertJUnit.assertEquals(printXPattern(6), "Pattern not printed successfully");
	}

	@Test(enabled = true, priority = 7)
	public void Test3XPattern() {

		AssertJUnit.assertEquals(printXPattern(0), "Pattern not printed successfully");
	}
	
	@Test(enabled = true, priority = 8)
	public void Test4XPattern() {

		AssertJUnit.assertEquals(printXPattern(-1), "Pattern not printed successfully");
	}




	public String printChristmasTree(int height)
	{

		if(height>1) {

			for(int i = 1;i <= height;i++){

				for(int j = height-i;j > 0;j--){

					System.out.print(" ");

				}
				for(int k = 1;k <= i;k++){

					System.out.print("* ");

				}
				System.out.println();
			}
			return "Pattern printed successfully";
		}
		else {

			System.out.println("Please enter a value greater than 2 next time!");
			return "Pattern not printed successfully";
		}

	}

	public String printXPattern(int height) {	

		if(height%2 != 0 && height>2) {
			for (int i = 1; i <= height; i++ ) 
			{
				for (int j = 1; j <= height; j++ ) 
				{
					if(j == i || j == (height - i) +1) 
					{
						System.out.print("*");
					}
					else 
						System.out.print(" ");
				}
				System.out.println();
			}
			return "Pattern printed successfully";
		}
		else {
			System.out.println("You won't get a cross this way");
			return "Pattern not printed successfully";
		}
	}

}
